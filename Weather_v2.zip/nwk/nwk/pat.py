from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.views.generic import TemplateView
from pages.models import ipdata
from pages.welcomemessage import welcome


import socket   


def adm(request):
	a="welcome"
	rs=render(request, 'holidays.html',{"festival_list":"Birthday und Holi und Diwali"});
	return rs;

def adm123(request):
	a="welcome"
	all_entries = ipdata.objects.all();
	print(type(all_entries));
	print(all_entries);
	s=[];
	#print(str(all_entries.query()));
	for i in all_entries:
		print(i);
		print(type(i));
		print(i.ipsite + " " + i.ipcountry);
		s.append(i.ipsite + " " + i.ipcountry);
	#	print(i.headline);
	#	print(i.headline);
	rs=render(request, 'hoidays.html',{"data1":s,"super":"rajini"});
	return rs
	
def adm1(request):
	a="welcome"
	dat=request.GET.get('name');
	print(type(dat));
	#id_fil=ipdata.objects.get(ipcountry="google.com"); Coloumn vased filter
	id_fil=ipdata.objects.get(id=dat);
	print(id_fil.ipsite+" "+id_fil.ipcountry);
	s=[];
	s.append(id_fil.ipsite + " " + id_fil.ipcountry);
	rs=render(request, 'hoidays.html',{"data1":s,"super":"rajini"});
	return rs