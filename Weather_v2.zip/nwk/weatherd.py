import urllib
import requests
from bs4 import BeautifulSoup
from pprint import pprint
latitude='10.1640832'
longitude='76.2158654'
apikey='04bbdf6d0d86119264f51166c067afcb'

def veronica(latitude,longitude,apikey=apikey):
	url='https://api.openweathermap.org/data/2.5/weather?lat=%s&lon=%s&appid=%s&units=metric'%(latitude,longitude,apikey)
	print(url)
	
	#rs=requests.get('http://api.openweathermap.org/data/2.5/weather?q=Berlin&APPID=04bbdf6d0d86119264f51166c067afcb&&units=metric');
	rs=requests.get(url);
	rsj=rs.json();
	#print(rsj)
	pprint(rsj)
	print("Your City name is : "+ str(rsj["name"]))
	print("Your City temperature is : "+str(rsj["main"]["temp"]))
	return rsj;


veronica(latitude,longitude)