from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from django.views.generic import TemplateView
from pages.models import ipdata
from pages.welcomemessage import welcome
from pages.weatherd import veronica
from reportlab.pdfgen import canvas
from io import BytesIO
from django.conf import settings
from django.core.files.storage import FileSystemStorage
from django.core.mail import send_mail
import urllib
from urllib.request import Request, urlopen

from bs4 import BeautifulSoup
import requests
import webbrowser

from django.core.mail import EmailMessage
from pages.mform import DocumentForm


from django.http import Http404
from rest_framework.views import APIView
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.http import JsonResponse
from django.core import serializers
import json
import socket 
import pygeoip


def myd(request):
	response=requests.get('https://api.myjson.com/bins/gkaow')
	#Way to request a url . Json stored at the above site
	json_data = response.json()
	print(json_data);
	try:
		
		ip=json_data['name']
		country= json_data['age']
		print('Done');
		print(type(country));
#	return render(request, 'core/home.html', {
#        'ip': geodata['ip'],
#	    'country': geodata['country_name']
 #   })
		#return 1;
		return HttpResponse('<h1> Your Age  is '+str(country));
	except Exception as e:
		return HttpResponse('<h1>ERROR </h1>' + e);
		print(e);

def ip1234(request):
	print('hi');
	#print(request.get['REMOTE_ADDR']);
	metadata= request.META.get('REMOTE_ADDR');
	print(metadata)
	#ip=request.remote_addr
	print('Hi');
	ipv4String = "117.213.21.253"
	gi = pygeoip.GeoIP('GeoIP.dat',flags=pygeoip.const.MMAP_CACHE)	
	j=gi.country_code_by_addr(ipv4String)
	print("country is " + j);
	#print(country_code);
	#print(ip);
	return render(request, 'ipme.html',{"ip":metadata})

#	return HttpResponse('<h1> Your Internet Address is '+metadata);
def websc(request):
	print('hi');
	#print(request.get['REMOTE_ADDR']);
	metadata= request.META.get('HTTP_USER_AGENT');
	print(metadata)
	return HttpResponse('<h1> Your Web agent is '+metadata);

def clim(request):
	print('hi');
	#print(request.get['REMOTE_ADDR']);
	metadata= request.META.get('HTTP_USER_AGENT');
	print(metadata)
	ip="https://upload.wikimedia.org/wikipedia/commons/b/b4/Rhodes_wild_Cynara.JPG"
	ip="https://upload.wikimedia.org/wikipedia/commons/1/17/20190212_SKJ0426-HDR-2.jpg"
	return render(request, 'clim.html',{"ip":ip})

def climd(request):
	print('hi');
	lat=request.GET['lat'];
	print(lat);
	long1=request.GET['long']
	print(long1)
	apiw=veronica(lat,long1)
	a=str(apiw["main"]["temp"])
	#print(request.get['REMOTE_ADDR']);
	#metadata= request.META.get('HTTP_USER_AGENT');
	#print("26 Degew")
	#a="23.4D"
	if (int(a)>30):
		urlim="https://upload.wikimedia.org/wikipedia/commons/c/ca/Vontut_National_Park.jpg"
	elif (int(a)>=35):
		urlim="https://upload.wikimedia.org/wikipedia/commons/6/66/Agasthiyamalai_range_and_Tirunelveli_rainshadow.jpg"
	else:
		urlim="https://upload.wikimedia.org/wikipedia/commons/3/36/Everglades_Sawgrass_Prairie_Moni3.JPG"
	apiw["ip"]=urlim;
	return JsonResponse(apiw)

#	return render(request, 'clim.html',{"ip":a})



def intra(request):
	print('Hello');
	count=0;
	while(1):
		print('hello');
		count=count+1;
	print('End');
	return HttpResponse('<h1> Your Internet Address is '+metadata);
	
	
		



class restg1(APIView):
    def get(self, request):
        #do something with 'GET' method
        return Response("some data")

    def post(self, request):
        #do something with 'POST' method
        return Response("some data")

def rest1(request):
	print("Hi");
	
	return JsonResponse("Ideal weight should be:"+str(100)+" kg",safe=False)

@api_view(["POST"])
def rest2(heightdata):
    try:
        height=json.loads(heightdata.body)
        weight=str(height*10)
        return JsonResponse("Ideal weight should be:"+weight+" kg",safe=False)
    except ValueError as e:
        return Response(e.args[0],status.HTTP_400_BAD_REQUEST)
		
		
@api_view(["POST"])
def rest3(height):
    try:
        height1=json.loads(height.body)
        #height=1.75
        weight=str(height1*10)
        #return Response('welcome')
        return Response("Ideal weight should be:"+weight+" kg")
        #return JsonResponse("Ideal weight should be:"+weight+" kg",safe=False)

    except ValueError as e:
        return Response(e.args[0],status.HTTP_400_BAD_REQUEST)

#@api_view(["GET"])
#def restg1(height):
#    try:
#        #height1=json.loads(height.body)
 #       height=1.75
  #      return JsonResponse("Ideal weight should be:"+weight+" kg",safe=False)
#
 #       print('hi');
  #      weight=str(height1*10)
   #     #return Response('welcome')
    #    #return Response("Ideal weight should be:"+weight+" kg")
     #   #return JsonResponse("Ideal weight should be:"+weight+" kg",safe=False)

    #except ValueError as e:
     #   return Response(e.args[0],status.HTTP_400_BAD_REQUEST)



def share1(request):
	
	print("From shaere 1");
	rq=request.GET['the_post'];
	print(rq);
	#quote_page = "https://money.rediff.com/companies/"+rq;
	quote_page = "https://money.rediff.com/companies/"+rq;
	
	#page = urllib.request.urlopen(quote_page)
	page = urllib.request.Request(quote_page)	
	#a='https://www.google.co.in/search?q=tcs+share+price'
	#print(page);
	req = Request(quote_page, headers={'User-Agent': 'Mozilla/5.0'})
	webpage = urlopen(req).read()

	#print(webpage);

	#print(type(page));
	#print(page.text);
	soup = BeautifulSoup(webpage, "html.parser")
	#print(soup);
	a=soup.prettify()
	price_box = soup.find("span",attrs={"id":"ltpid"})
	print(price_box);
	return HttpResponse('Sharing Share data  '+price_box.text)

#USER_AGENT = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/61.0.3163.100 Safari/537.36'}
def share111(request):
	
	print("From shaere 1");
	rq=request.GET['the_post'];
	print(rq);
	#quote_page = "https://money.rediff.com/companies/"+rq;
	quote_page = "https://money.rediff.com/companies/"+rq;
	
	page = urllib.request.urlopen(quote_page)
	soup = BeautifulSoup(page, "html.parser")
	print(soup);
	#price_box = soup.find("span", attrs={"id":"ltpid"})
	#print(price_box.text);
	#a=price_box.text;
	return HttpResponse('Sharing Share data  ')

	

def sharegg(request):
#googl3 didnt work .Another way to scrap . Here img or link	
	
	#quote_page = 'https://google.com/search?q=' + 'tcs'
	#quote_page = "https://money.rediff.com/companies/"+rq;
	quote_page='http://edmundmartin.com/scraping-google-with-python/'
	page = requests.get(quote_page)
	print(type(page))
	print('doone-1');
	#print(page);
	#print(page.text);
	soup = BeautifulSoup(page.text, 'html.parser')
	print('done0')
	found_results = []
	rank = 1
	price_box = soup.find("img",attrs={"class":"aligncenter size-large wp-image-309"})
	print('done');
	#print(found_results)
	print(price_box);
	return HttpResponse(price_box)

	
	
	
def sharegg1(request):
	
	text = 'tcs'
	text = urllib.parse.quote_plus(text)
	
	url = 'https://google.com/search?q=' + text
	#url='https://www.digitalocean.com/community/tutorials/how-to-work-with-web-data-using-requests-and-beautiful-soup-with-python-3'
	#IsqQVc NprOob i8nCUE83Oppc-zJFzKq8ukm8
	responses = requests.get(url)
	#print(responses.text);
	a=responses.text;
	soup = BeautifulSoup(a, "html.parser")
	print(soup.prettify());
	price_box = soup.find("span", attrs={"class":"IsqQVc NprOob i8nCUE83Oppc-zJFzKq8ukm8"})
	print(price_box)
	#print(price_box.text);
	#a=price_box.text;


	print('done')

#with open('output.html', 'wb') as f:
#    f.write(response.content)
#webbrowser.open('output.html')


	return HttpResponse(soup.text)

	
	
	
def share(request):
	return render(request, 'share_value.html',{"festival_list":"Birthday und Holi und Diwali"})


	

def model_form_upload(request):
    if request.method == 'POST':
        form = DocumentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
			
            return render(request, 'mforma.html', {
        'form': form,'ww':"form Uploaded"
    })

    else:
        form = DocumentForm()
    return render(request, 'mforma.html', {
        'form': form
    })

def kaalakilla(request):
    c = canvas.Canvas("hello.pdf")
    c.drawString(100,750,"Welcome to Reportlab!")
    c.save()
    print("PDF DONE");
    return HttpResponse('Rajini, Star!')
	

# Create your views here.

def arunvenu(request):
    # Create the HttpResponse object with the appropriate PDF headers.
    response = HttpResponse(content_type='application/pdf')
    response['Content-Disposition'] = 'inline;filename="somefilename.pdf"'

    buffer = BytesIO()

    # Create the PDF object, using the BytesIO object as its "file."
    p = canvas.Canvas(buffer)

    # Draw things on the PDF. Here's where the PDF generation happens.
    # See the ReportLab documentation for the full list of functionality.
    p.drawString(100, 100, "Hello world.")

    # Close the PDF object cleanly.
    p.showPage()
    p.save()

    # Get the value of the BytesIO buffer and write it to the response.
    pdf = buffer.getvalue()
    buffer.close()
    file = open("contract.pdf", "wb")
    file.write(pdf)
    response.write(pdf)
    return response 
def admin(request):
    return HttpResponse('I Belss you')
	
class nagpur(TemplateView):
    template_name = 'tamil.html'
	
	
def holidays(request):
    festival_list = ["Birthday", 'Holi', 'Diwali'];
    return render(request, 'hoidays.html',{"festival_list":"Birthday und Holi und Diwali"})

def site_ip(request):
	if request.method == "GET":
		request.session['name'] = 'Ludwik'
		#print('Ok');
		#host = socket.gethostbyname("www.python.com")
		#print(host);
		website=" ";
		website=request.GET.get('the_post');
		
		print('From site_ip view')
		print(website)
		if website is None:
			website=""
			return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali"})
			
		print(website);
		hostname = socket.gethostname()   
		IPAddr = socket.gethostbyname(hostname)  
		web_ip="";
		try:
			
			web_ip=socket.gethostbyname(website)
			print(web_ip);
		except:
			print("Internal Error arun");
		
		print("Your Computer Name is:" + hostname)   
		print("Your Computer IP Address is:" + IPAddr)   
		dbsave1(web_ip,website);
		return HttpResponse('Sharing Share data :  '+web_ip)
		print("NLM")
		return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali","web_ip":web_ip,"ww":website})

	else:

		return render(request, 'web_ip.html',{"festival_list":"Birthday und Holi und Diwali"})

def site_ipj(request):
	if request.method == "GET":
		request.session['name'] = 'Ludwik'
		#print('Ok');
		#host = socket.gethostbyname("www.python.com")
		#print(host);
		website=" ";
		website=request.GET.get('website');
		print("Its in Site_ipj");
		print('From site_ip view')
		print(website)
		if website is None:
			website=""
			return render(request, 'web_ip1.html',{"festival_list":"Birthday und Holi und Diwali"})
			
		print(website);
		hostname = socket.gethostname()   
		IPAddr = socket.gethostbyname(hostname)  
		web_ip="";
		try:
			
			web_ip=socket.gethostbyname(website)
			print(web_ip);
		except:
			print("Internal Error arun");
		
		print("Your Computer Name is:" + hostname)   
		print("Your Computer IP Address is:" + IPAddr)   
		dbsave1(web_ip,website);
		adata = {}
		adata['message'] = 'Welcome '
		adata['ip'] = str(web_ip);
		#print("NLM")
		return JsonResponse(adata);		
#		return JsonResponse("Ideal weight should be:"+str(100)+" kg",safe=False);
		return HttpResponse('Sharing Share data :  '+web_ip)
		#print("NLM")
		return render(request, 'web_ip1.html',{"festival_list":"Birthday und Holi und Diwali","web_ip":web_ip,"ww":website})

	else:

		return render(request, 'web_ip1.html',{"festival_list":"Birthday und Holi und Diwali"})




def dbsave1(ip,website):
	
	p = ipdata(ipsite=ip, ipcountry=website);
	print("Inserted");
	d=welcome();
	print(d);
	p.save()
	pass;
	
def ssend(request):
		print(request.session['name'])
		a=request.session['name']
		#send_mail(a, 'Everything will be fine', 'developerarunvgk', ['venuarunv@gmail.com']);
		a=request.POST['email'];
		file1=request.FILES['fileToUpload'];
		fs = FileSystemStorage()
		filename = fs.save(file1.name, file1)
		uploaded_file_url = fs.url(filename)
		email = EmailMessage()
		email.subject = "New shirt submitted"
		email.body = "<h1>I am good</h1>"
		email.from_email = "Arun V! <developerarunvgk@gmail.com>"
		email.to = [ "venugarunv@gmail.com",] 
		uploaded_file_url="/home/arunvgk/Downloads/django123/nwk"+uploaded_file_url;

		email.attach_file(uploaded_file_url) # Attach a file directly
		print(a);
		print(file1);
		#email.send()

		print("Mail send");
		return HttpResponse('file uploaded at '+uploaded_file_url + " . Email has been suscessfully sent")

def forma(request):
		return render(request, 'form1.html',{"festival_list":"Birthday und Holi und Diwali"})
