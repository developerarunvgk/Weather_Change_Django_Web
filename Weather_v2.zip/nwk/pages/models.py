from django.db import models

#Create your models here.

class Category(models.Model):
    categoryName = models.CharField(max_length=100)

class Product(models.Model):
    productCategory = models.ForeignKey(Category, on_delete=models.CASCADE)
    productName = models.CharField(max_length=100)
    productPrice = models.IntegerField()
    productBrand = models.CharField(max_length=100)
	
	
class ipdata(models.Model):
    ipsite = models.CharField(max_length=100);
    ipcountry=models.CharField(max_length=100);
	
	

class Document(models.Model):
    description = models.CharField(max_length=255, null=True, default='Please enter Description',)
    document = models.FileField(upload_to='documents/')
    uploaded_at = models.DateTimeField(auto_now_add=True)